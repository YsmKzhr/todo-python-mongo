import uuid

# app settings
APP_SECRET = str(uuid.uuid4())
JWT_SECRET = str(uuid.uuid4())
MAX_CONTENT_SIZE = 200