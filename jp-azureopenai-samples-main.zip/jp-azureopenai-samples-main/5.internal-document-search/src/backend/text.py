def nonewlines(s: str) -> str:
    return s.replace('\n', ' ').replace('\r', ' ')

